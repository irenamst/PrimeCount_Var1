﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp9
{
    internal class Program
    {
        static int PrimeCount(long n)
        {
            int result;
            int L=100;
            bool[] flag = new bool[L+1];
            for(int i = 4; i <=L; i += 2)
            {
                flag[i] = true;
            }
            for (int i = 3; i * i <= L; i += 2)
            {
                if (!flag[i])
                {
                    for (int j = 2 * i; j <= L; j += i)
                    {
                        flag[j] = true;
                    }
                }
            }
            List<long> limits = new List<long>();
            limits.Add(2);
            long t = 2;
            for (int i = 3; i <= L && t > 0; i += 2)
            {
                if (!flag[i])
                {
                    t *= i;
                    if (t > 0) { limits.Add(t); }
                }
            }
            int br = 0;
            foreach (var item in limits)
            {
                if (item < n)
                {
                    br++;
                }
                else
                {
                    break;
                }
            }
            result = br;
            return result;
        }
        static void Main(string[] args)
        {
            long n;
            n=long.Parse(Console.ReadLine());
            int count = PrimeCount(n);
            Console.WriteLine(count);
        }
    }
}
